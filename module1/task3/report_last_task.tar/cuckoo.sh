#!/bin/bash

FIFO="/tmp/run/cuckoo.pid"
LOG="cuckoo.log"
PID=$$

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG"
}

mkdir -p /tmp/run
rm -f "$FIFO"
mkfifo "$FIFO"

trap 'log "Shutdown!"; rm -f "$FIFO"; exit 0' SIGTERM SIGINT

log "Startup!"

while true; do
    if read -r request < "$FIFO"; then
        if [[ "$request" =~ ^([^[]+)\[([0-9]+)\]: ]]; then
            NAME="${BASH_REMATCH[1]}"
            CLIENT_PID="${BASH_REMATCH[2]}"
            
            N=$((RANDOM % 9 + 2))
            
            log "$NAME[$CLIENT_PID] $N"
            
            echo "$N" > "$FIFO"
        fi
    fi
done
