#!/bin/bash

SCRIPT_NAME=$(basename "$0")
SCRIPT_FULL_NAME=$(basename "$0" .sh)
LOG="report_${SCRIPT_FULL_NAME}.log"
FIFO="/tmp/run/cuckoo.pid"
PID=$$

if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$PID] $1" >> "$LOG"
}

log "Скрипт запущен"

START_TIME=$(date +%s)
echo "${SCRIPT_FULL_NAME}[${PID}]: how much time do I have?" > "$FIFO"

if read -r N < "$FIFO"; then
    sleep "$N"
fi

END_TIME=$(date +%s)
WORK_TIME=$((END_TIME - START_TIME))
log "Скрипт завершился, работал $WORK_TIME секунд."
