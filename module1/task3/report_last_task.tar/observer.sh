#!/bin/bash


PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

SCRIPT_DIR=$(dirname "$(readlink -f "$0")")
cd "$SCRIPT_DIR" || exit 1

CONFIG="observer.conf"
LOG="observer.log"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG"
}

if [[ ! -f "$CONFIG" ]]; then
    log "ERROR: Конфигурационный файл $CONFIG не найден"
    exit 1
fi

while IFS= read -r script_path || [[ -n "$script_path" ]]; do
    [[ -z "$script_path" || "$script_path" =~ ^# ]] && continue
    
    script_path=$(echo "$script_path" | xargs)
    
    script_name=$(basename "$script_path")
    
    if ! pgrep -f "$script_name" > /dev/null; then
        log "Процесс $script_name не найден. Запуск..."
        
        cd "$SCRIPT_DIR"
        nohup "$script_path" >> /dev/null 2>&1 &
        
        log "Процесс $script_name запущен с PID $!"
    fi
done < "$CONFIG"
